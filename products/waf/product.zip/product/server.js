const express = require("express");
const path = require("path");

const app = express();
const PORT = 3004;
const HOST = "0.0.0.0"; // Tarmoqqa ochiq qilish

// Static fayllarni serve qilish
app.use(express.static(path.join(process.cwd(), "public")));

app.get("/", (req, res) => {
  res.sendFile(path.join(process.cwd(), "public", "index.html"));
});

// Serverni ishga tushirish
app.listen(PORT, HOST, () => {
  console.log(`${PORT}`);
  // Server IP manzilini olish
  // const interfaces = os.networkInterfaces();

  // const addresses = [];

  // for (let iface of Object.values(interfaces)) {
  //   for (let config of iface) {
  //     if (config.family === "IPv4" && !config.internal) {
  //       addresses.push(config.address);
  //     }
  //   }
  // }

  // console.log(`Server is running on:`);
  // addresses.forEach((addr) => console.log(`- http://${addr}:${PORT}`));
});
